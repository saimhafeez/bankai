import '../utils/enumerations.dart';

class CreditCardBrand {
  CreditCardBrand(this.brandName);

  CardType? brandName;
}
